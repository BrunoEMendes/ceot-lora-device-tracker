LHT65_FIELDS = {
    'bat':'device_frmpayload_data_BatV',
    'hum':'device_frmpayload_data_Hum_SHT',
    'tmp':'device_frmpayload_data_TempC_SHT',
    'ilx':'device_frmpayload_data_ILL_lux'
}

MAX_LHT65_DEVICES = 25