server='https://23.88.101.43'
port='8086'
org='ceot'
token='HQuhjRudPv_fmY-tEvCvaPapbKL4paqydZUdxgTELMjWok3NHpDlpGDPzNgisAUz1nonYbg96ClO5CDgLS9HcQ=='
